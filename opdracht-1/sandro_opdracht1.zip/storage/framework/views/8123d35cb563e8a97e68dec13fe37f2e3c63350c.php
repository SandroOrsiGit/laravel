<script src=<?php echo e(asset('js/jquery.min.js')); ?>></script>
<script src=<?php echo e(asset('js/jquery.scrollex.min.js')); ?>></script>
<script src=<?php echo e(asset('js/jquery.scrolly.min.js')); ?>></script>
<script src=<?php echo e(asset('js/browser.min.js')); ?>></script>
<script src=<?php echo e(asset('js/breakpoints.min.js')); ?>></script>
<script src=<?php echo e(asset('js/util.js')); ?>></script>
<script src=<?php echo e(asset('js/main.js')); ?>></script><?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-1\resources\views/includes/jquery-scripts.blade.php ENDPATH**/ ?>