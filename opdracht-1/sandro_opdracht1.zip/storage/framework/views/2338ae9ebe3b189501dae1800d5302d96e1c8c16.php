<nav id="nav">
    <ul>
        <li><a href="<?php echo e(route('home')); ?>" class="<?php echo e(Route::CurrentRouteName() == 'home' ? 'active' : ''); ?>">Home</a></li>
        <li><a href="<?php echo e(route('about')); ?>" class="<?php echo e(Route::CurrentRouteName() == 'about' ? 'active' : ''); ?>">About</a>
        </li>
        <li><a href="<?php echo e(route('get-started')); ?>"
                class="<?php echo e(Route::CurrentRouteName() == 'get-started' ? 'active' : ''); ?>">Get
                Started</a></li>
        <li><a href="<?php echo e(route('contact')); ?>"
                class="<?php echo e(Route::CurrentRouteName() == 'contact' ? 'active' : ''); ?>">Contact</a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-1\resources\views/includes/nav.blade.php ENDPATH**/ ?>