<?php $__env->startSection('header'); ?>
    <span class="logo"><img src=<?php echo e(asset('images/logo.svg')); ?> alt="" /></span>
    <h1>Stellar</h1>
    <p>Just another free, fully responsive site template<br /> built by <a href="https://twitter.com/ajlkn">@ajlkn</a> for <a
            href="https://html5up.net">HTML5 UP</a>.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Introduction -->
    <?php echo $__env->make('includes.intro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- First Section -->
    <?php echo $__env->make('includes/section-1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Second Section -->
    <?php echo $__env->make('includes.section-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Get Started -->
    <?php echo $__env->make('includes.get-started', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-1\resources\views/pages/index.blade.php ENDPATH**/ ?>