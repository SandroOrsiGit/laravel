<link rel="stylesheet" href=<?php echo e(asset('css/main.css')); ?> />
<noscript>
    <link rel="stylesheet" href=<?php echo e(asset('css/noscript.css')); ?> />
</noscript><?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-1\resources\views/includes/css-links.blade.php ENDPATH**/ ?>