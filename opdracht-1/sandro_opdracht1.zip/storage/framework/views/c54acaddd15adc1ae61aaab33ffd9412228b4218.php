<!DOCTYPE HTML>
<!--
 Stellar by HTML5 UP
 html5up.net | @ajlkn
 Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
    <title>Stellar by HTML5 UP</title>
    <?php echo $__env->make('includes/meta-tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes/css-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="is-preload">

    <!-- Wrapper -->
    <div id="wrapper">

        <!-- Header -->
        <header id="header" class="alt">
            <?php echo $__env->yieldContent('header'); ?>
        </header>

        <!-- Nav -->
        <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main -->
        <div id="main">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- Footer -->
        <?php echo $__env->make('includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('includes.jquery-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-1\resources\views/layouts/basic.blade.php ENDPATH**/ ?>