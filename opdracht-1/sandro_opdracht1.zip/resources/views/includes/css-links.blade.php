<link rel="stylesheet" href={{ asset('css/main.css') }} />
<noscript>
    <link rel="stylesheet" href={{ asset('css/noscript.css') }} />
</noscript>