<section id="cta" class="main special">
    <header class="major">
        <h2>Congue imperdiet</h2>
        <p>Donec imperdiet consequat consequat. Suspendisse feugiat congue<br /> posuere. Nulla massa urna, fermentum
            eget quam aliquet.</p>
    </header>
    <footer class="major">
        <ul class="actions special">
            <li><a href="getstarted.html" class="button primary">Get Started</a></li>
            <li><a href="about.html" class="button">Learn More</a></li>
        </ul>
    </footer>
</section>