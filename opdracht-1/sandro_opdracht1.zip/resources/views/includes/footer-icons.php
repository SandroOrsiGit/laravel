<ul class="icons">
    <li><a href="#" class="icon brands fa-twitter alt"><span class="label">Twitter</span></a>
    </li>
    <li><a href="#" class="icon brands fa-facebook-f alt"><span class="label">Facebook</span></a>
    </li>
    <li><a href="#" class="icon brands fa-instagram alt"><span class="label">Instagram</span></a>
    </li>
    <li><a href="#" class="icon brands fa-github alt"><span class="label">GitHub</span></a></li>
    <li><a href="#" class="icon brands fa-dribbble alt"><span class="label">Dribbble</span></a>
    </li>
</ul>