<section id="intro" class="main">
    <div class="spotlight">
        <div class="content">
            <header class="major">
                <h2>Ipsum sed adipiscing</h2>
            </header>
            <p>Sed lorem ipsum dolor sit amet nullam consequat feugiat consequat magna adipiscing magna etiam amet
                veroeros. Lorem ipsum dolor tempus sit cursus. Tempus nisl et nullam lorem ipsum dolor sit amet aliquam.
            </p>
            <ul class="actions">
                <li><a href="about.html" class="button">Learn More</a></li>
            </ul>
        </div>
        <span class="image"><img src={{ asset('images/pic01.jpg') }} alt="" /></span>
    </div>
</section>