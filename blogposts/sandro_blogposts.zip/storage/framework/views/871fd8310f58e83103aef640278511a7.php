<?php $__env->startSection('title', 'Edit post'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <h2>Edit post</h2>

        <p>
            <a href="/posts/<?php echo e($post->id); ?>">Back to post</a>
        </p>

        <form action="<?php echo e(route('posts.update', $post)); ?>" method="post">
            <?php echo method_field('put'); ?>
            <?php echo $__env->make('posts.includes.form', ['buttonText' => "Update"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/posts/edit.blade.php ENDPATH**/ ?>