<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?> - Default Layout</title>
    <link rel="stylesheet" href="/styles/styles.css">
</head>
<body>

    <div class="container">
        <header>
            <h1>Databank communicatie</h1>
            <nav class="main-nav">
                <a href="/">Home</a>
                <a href="<?php echo e(route('posts.create')); ?>">Add new post</a>
                <a href="<?php echo e(route('users.profile')); ?>">My profile</a>
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login.get')); ?>">Login</a>
                <a href="<?php echo e(route('register.get')); ?>">Register</a>
                <?php endif; ?>
            </nav>
        </header>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer class="main-footer">
            <p>Made with Laravel!
                <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('logout')); ?>">Logout</a></p>
                <?php endif; ?>
        </footer>
    </div>

</body>
</html>
<?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/layouts/default.blade.php ENDPATH**/ ?>