<blockquote class="comment">
    <q class="comment-content">
        <?php echo e($comment->content); ?>

    </q>
    <cite class="comment-cite">
        by <a href="<?php echo e(route('users.show', $comment->user)); ?>"><?php echo e($comment->user->name); ?></a>
    </cite>

    <?php if(auth()->id() == $comment->user_id): ?>
    <div class="comment-actions">
        <a href="<?php echo e(route('comments.edit', $comment)); ?>">edit</a>

        or

        <form action="<?php echo e(route('comments.destroy', $comment)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field("DELETE"); ?>
            <input type="submit" value="delete">
        </form>
    </div>
    <?php endif; ?>
</blockquote>
<?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/comments/includes/comment.blade.php ENDPATH**/ ?>