<article class="post-small">
    <h1 class="post-small-title">
        <a href="<?php echo e(route('posts.show', $post)); ?>">
            <?php echo e($post->title); ?>

        </a>
    </h1>
    <p class="post-small-subtitle">
        <?php echo e($post->subtitle); ?>

    </p>
    <p class="post-small-username">
        written by <a href="<?php echo e(route('users.show', $post->user)); ?>"><?php echo e($post->user->username); ?></a>
    </p>
    <div class="post-small-content">
        <?php if(strlen($post->content) > 100): ?>
            <?php echo e(substr($post->content, 0, 100)); ?>...
        <?php else: ?>
            <?php echo e($post->content); ?>

        <?php endif; ?>
    </div>
    <footer>
        <a class="post-small-readmore" href="<?php echo e(route('posts.show', $post)); ?>">Read more &rarr;</a>
    </footer>
</article>
<?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/posts/includes/post-small.blade.php ENDPATH**/ ?>