<?php echo csrf_field(); ?>
<div class="form-content">

    <div class="form-element">
        <div>
            <label for="title">Title</label>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <input type="text" name="title" id="title" value="<?php echo e(old('title', $post->title)); ?>">
    </div>

    <div class="form-element">
        <div>
            <label for="subtitle">Subtitle</label>
            <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <input type="text" name="subtitle" id="subtitle" value="<?php echo e(old('subtitle', $post->subtitle)); ?>">
    </div>

    <?php if($post->id): ?>
    <div class="form-element">
        <div>
            <label for="url">Url</label>
            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <input type="text" name="url" id="url" value="<?php echo e(old('url', $post->url)); ?>">
    </div>
    <?php endif; ?>

    <div>
        <label>
            <input type="checkbox" value="1" name="published" id="published" <?php echo e(old('published', $post->published) ? 'checked' : ''); ?>>
            Published
        </label>
        <?php $__errorArgs = ['published'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="form-error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-element">
        <div>
            <label for="status">Status</label>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <select name="status" id="status">
            <?php $__currentLoopData = ['draft', 'final']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($option); ?>" <?php echo e(old('status', $post->status) == $option ? 'selected' : ''); ?>>
                    <?php echo e(ucfirst($option)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-element">
        <div>
            <label for="content">Content</label>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <textarea name="content" id="content"><?php echo e(old('content', $post->content)); ?></textarea>
    </div>

    <div>
        <input type="submit" value="<?php echo e($buttonText ?? 'Save'); ?>">
    </div>

</div>
<?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/posts/includes/form.blade.php ENDPATH**/ ?>