<?php $__env->startSection('title', 'Edit comment'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <h2>Edit comment</h2>

        <p>
            <a href="/posts/<?php echo e($comment->post->id); ?>">Back to post</a>
        </p>

        <form action="<?php echo e(route('comments.update', $comment)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('comments.includes.form', ['buttonText' => "Update"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/comments/edit.blade.php ENDPATH**/ ?>