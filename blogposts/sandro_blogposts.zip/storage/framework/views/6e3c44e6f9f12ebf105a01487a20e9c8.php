<?php $__env->startSection('title', 'My profile'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <h2>User: <?php echo e($user->username); ?></h2>
        <p>
            Name: <?php echo e($user->name); ?>

        </p>

        <h3>My recect posts</h3>
        <div class="posts-list">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo $__env->make('posts.includes.post-small', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No posts have been added yet.</p>
            <?php endif; ?>
        </div>
        <div class="pagination">
            <?php echo e($posts->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/users/show.blade.php ENDPATH**/ ?>