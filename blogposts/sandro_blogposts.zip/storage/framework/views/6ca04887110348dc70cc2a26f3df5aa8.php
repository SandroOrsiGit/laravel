<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <h2>Login</h2>

        <p>
            <a href="<?php echo e(route('register.get')); ?>">Or register for a new account</a>
        </p>

        <form action="<?php echo e(route('login.post')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-content">
                <div class="form-element">
                    <div>
                        <label for="username">Username</label>
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input type="text" name="username" id="username" value="<?php echo e(old('username')); ?>">
                </div>
                <div class="form-element">
                    <div>
                        <label for="password">Password</label>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input type="password" name="password" id="password">
                </div>

                <div>
                    <input type="submit" value="Login">
                </div>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/auth/login.blade.php ENDPATH**/ ?>