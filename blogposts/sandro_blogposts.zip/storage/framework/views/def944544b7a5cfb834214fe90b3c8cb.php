<?php $__env->startSection('title', 'Add new post'); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <h2>Add new post</h2>

        <form action="<?php echo e(route('posts.store')); ?>" method="post">
            <?php echo $__env->make('posts.includes.form', ['buttonText' => "Add"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/posts/create.blade.php ENDPATH**/ ?>