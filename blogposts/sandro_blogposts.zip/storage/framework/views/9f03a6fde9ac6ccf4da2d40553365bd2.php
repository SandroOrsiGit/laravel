<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>
    <section class="post-details">
        <header class="post-header">
            <h2 class="post-title"><?php echo e($post->title); ?></h2>
            <p class="post-subtitle"><?php echo e($post->subtitle); ?></p>
            <p class="post-username">
                Written by <a href="<?php echo e(route('users.show', $post->user)); ?>"><?php echo e($post->user->username); ?></a>
            </p>
        </header>

        <?php if(auth()->id() == $post->user_id): ?>
        <div class="post-actions">
            <a href="<?php echo e(route('posts.edit', $post)); ?>">Edit this post</a> or
            <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="post">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <input type="submit" value="Delete this post">
            </form>
        </div>
        <?php endif; ?>

        <div>
            <?php echo e($post->content); ?>

        </div>

        <aside class="comments">
            <h3>Comments</h3>
            <div class="comment-section">
                <div class="comment-form">
                    <form action="<?php echo e(route('comments.store')); ?>" method="post">
                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                        <?php echo $__env->make('comments.includes.form', ['buttonText' => "Add comment"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
                <div class="comments-list">
                    <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo $__env->make('comments.includes.comment', ['comment' => $comment], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No comments yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </aside>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/posts/show.blade.php ENDPATH**/ ?>