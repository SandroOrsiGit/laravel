<?php echo csrf_field(); ?>

<div class="form-content">

    <div class="form-element">
        <div>
            <label for="content">Content</label>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <textarea name="content" id="content"><?php echo e(old('content', $comment->content)); ?></textarea>
    </div>

    <div>
        <input type="submit" value="<?php echo e($buttonText ?? 'Save'); ?>">
    </div>

</div>
<?php /**PATH C:\Users\SOPFG\OneDrive\Desktop\laravel\blogposts\resources\views/comments/includes/form.blade.php ENDPATH**/ ?>