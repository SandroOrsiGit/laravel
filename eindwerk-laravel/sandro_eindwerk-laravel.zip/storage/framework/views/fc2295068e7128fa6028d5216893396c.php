<form class="my-8" action="<?php echo e(route('cart.add', $product)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="flex gap-4">
        <div class="relative flex-1">
            <select class="rounded-none w-full block py-2 px-4 bg-white appearance-none border border-gray-500"
                name="size" id="">
                <?php $__currentLoopData = $product->available_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($size); ?>"><?php echo e($size); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="absolute right-4 inset-y-0 flex items-center">
                <i class="fa-regular fa-arrows-up-down"></i>
            </div>
        </div>
        <div class="">
            <input placeholder="Aantal" value="1" min="1"
                class="py-2 px-4 bg-white appearance-none border border-gray-500" type="number" name="quantity">
        </div>
    </div>
    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="my-4 flex gap-4">
        <button class="block hover:bg-gray-800 bg-black text-white px-4 py-2 w-full" type="submit">
            Bestel nu!
        </button>
        <?php echo $__env->make('store.includes.favorite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__errorArgs = ['alreadyInCart'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</form>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\eindwerk-laravel\resources\views/store/includes/order-form.blade.php ENDPATH**/ ?>