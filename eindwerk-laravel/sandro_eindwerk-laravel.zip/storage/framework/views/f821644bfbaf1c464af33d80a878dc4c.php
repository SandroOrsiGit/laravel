<h1>Your email address has ben changed</h1>
<p>Your email address has been changed to <?php echo e($email); ?></p>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\eindwerk-laravel\resources\views/mails/changedMail.blade.php ENDPATH**/ ?>