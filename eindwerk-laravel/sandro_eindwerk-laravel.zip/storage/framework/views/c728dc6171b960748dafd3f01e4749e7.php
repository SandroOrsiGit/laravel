<div class="relative">
    <div class="relative">
        <img src="<?php echo e(asset('images/'.$product->image)); ?>" alt="<?php echo e($product->name); ?>">
        <div class="absolute z-10 top-4 right-0">
            <?php echo $__env->make('store.includes.favorite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <a class="absolute inset-0" href="<?php echo e(route('products.show', $product)); ?>">
            <span class="hidden">Toon product</span>
        </a>
    </div>
    <a href="<?php echo e(route('brands.show', $product->brand)); ?>" class="hover:underline text-gray-500"><?php echo e($product->brand->name); ?></a>
    <h1 class="text-lg">
        <a class="hover:underline" href="<?php echo e(route('products.show', $product)); ?>"><?php echo e($product->name); ?></a>
    </h1>
    <p class="text-sm text-gray-800">
        <?php echo e($product->description); ?>

    </p>
    <p class="text-lg">&euro;<?php echo e($product->price); ?></p>

</div>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\eindwerk-laravel\resources\views/store/includes/product-small.blade.php ENDPATH**/ ?>