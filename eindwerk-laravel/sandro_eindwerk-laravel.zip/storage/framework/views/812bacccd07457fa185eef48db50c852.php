<h1>Order Placed Succesfully</h1>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quisquam fugit doloremque quo aliquid quaerat atque nisi ad
    quas possimus vitae, incidunt esse dolores eius minima architecto voluptatem placeat maiores inventore!</p>
<a href="<?php echo e('http://eindwerk-laravel.test/orders/' . $order_id); ?>">Link naar uw order</a>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\eindwerk-laravel\resources\views/mails/orderPlaced.blade.php ENDPATH**/ ?>