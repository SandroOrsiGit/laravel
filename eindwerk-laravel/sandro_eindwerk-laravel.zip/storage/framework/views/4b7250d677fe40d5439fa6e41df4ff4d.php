<?php $__env->startSection('title', 'My favorites'); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-6 gap-24">
        <div class="col-span-2">
            <h1 class="text-4xl font-semibold mb-4">Aanmelden</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum corporis perferendis reprehenderit alias
                eligendi laudantium quisquam magnam, totam vel nobis maxime nemo aliquid impedit ipsam repellendus autem eos
                doloribus iste.</p>
        </div>
        <div class="col-span-4">
            <form action="<?php echo e(route('login.post')); ?>" method="post" novalidate class="flex flex-col gap-4">
                <?php echo csrf_field(); ?>

                <div class="flex flex-col">
                    <label class="text-gray-500" for="email">E-mailadres: *</label>
                    <input name="email" value="<?php echo e(old('email')); ?>" type="email"
                        class="bg-white border border-gray-500 px-4 py-2">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex flex-col">
                    <label class="text-gray-500" for="password">Wachtwoord: *</label>
                    <input name="password" type="password" class="bg-white border border-gray-500 px-4 py-2">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <button type="submit"
                        class="mt-4 block hover:bg-orange-600 bg-orange-500 uppercase text-center font-semibold text-lg cursor-pointer text-white px-4 py-2 w-full">
                        Login
                    </button>
                    <p class="text-center mt-4">of <a class="hover:underline text-orange-500"
                            href="<?php echo e(route('register')); ?>">registreer een nieuwe account</a></p>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fuw\Desktop\github\laravel\eindwerk-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>