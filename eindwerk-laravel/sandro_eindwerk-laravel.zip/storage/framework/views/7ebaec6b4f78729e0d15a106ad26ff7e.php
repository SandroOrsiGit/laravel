<?php if(auth()->guard()->check()): ?>
    <div class="bg-gray-100 py-2 px-4">
        <div class="container mx-autp px-4 flex justify-center gap-8">
            <a href="<?php echo e(route('profile.edit')); ?>" class="hover:underline">
                <i class="fa-solid fa-user-pen"></i>
                Wijzig profiel
            </a>
            <a href="<?php echo e(route('favorites')); ?>" class="hover:underline">
                <i class="fa-solid fa-heart"></i>
                Favorieten
            </a>
            <a href="<?php echo e(route('orders.index')); ?>" class="hover:underline">
                <i class="fa-solid fa-bag-shopping"></i>
                Mijn bestellingen
            </a>
            <a href="<?php echo e(route('logout')); ?>" class="hover:underline">
                <i class="fa-solid fa-right-from-bracket"></i>
                Afmelden
            </a>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\eindwerk-laravel\resources\views/layouts/includes/user-menu.blade.php ENDPATH**/ ?>