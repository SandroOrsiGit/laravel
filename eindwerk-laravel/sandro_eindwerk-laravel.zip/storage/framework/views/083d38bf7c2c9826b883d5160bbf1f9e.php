<h1>Welcome to Shoestore!</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum suscipit, laborum a consectetur exercitationem id
    accusantium est quisquam repellat quaerat ullam sit! Corrupti aspernatur iste voluptatum fugit consequuntur maxime
    iure?</p>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\eindwerk-laravel\resources\views/mails/newAccount.blade.php ENDPATH**/ ?>