<div class="relative bg-gray-100 p-4 flex justify-between items-center relative">
    <div>
        <h1 class="text-xl font-semibold">Bestelling van <?php echo e($order->created_at); ?></h1>
        <p class="text-gray-500 text-lg"><?php echo e($order->products()->count()); ?> producten</p>
    </div>
    <div class="text-4xl">
        <i class="fa-solid fa-angle-right"></i>
    </div>
    <a class="absolute inset-0" href="<?php echo e(route('orders.show', ['order' => $order])); ?>">
        <span class="hidden">Toon bestelling</span>
    </a>
</div>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\eindwerk-laravel\resources\views/orders/includes/order.blade.php ENDPATH**/ ?>