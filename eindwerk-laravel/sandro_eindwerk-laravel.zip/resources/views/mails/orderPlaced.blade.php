<h1>Order Placed Succesfully</h1>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quisquam fugit doloremque quo aliquid quaerat atque nisi ad
    quas possimus vitae, incidunt esse dolores eius minima architecto voluptatem placeat maiores inventore!</p>
<a href="{{ 'http://eindwerk-laravel.test/orders/' . $order_id }}">Link naar uw order</a>
