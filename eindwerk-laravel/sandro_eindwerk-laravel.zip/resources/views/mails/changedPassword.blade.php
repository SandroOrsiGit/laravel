<h1>Your password has been changed</h1>
<p>Your password has been changed!</p>
<p>If this wasn't you please <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ">click here</a> to recover your account
</p>
