<h1>Your email address has been changed</h1>
<p>Your email address has been changed to {{ $email }}</p>
<p>If this wasn't you please <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ">click here</a> to recover your account
</p>
