<?php

declare(strict_types=1);

return [
    'failed'   => 'Deze combinatie van e-mailadres en wachtwoord is niet geldig.',
    'password' => 'Wachtwoord is onjuist.',
    'throttle' => 'Te veel mislukte aanmeldpogingen. Probeer het nog eens over :seconds seconden.',
];
