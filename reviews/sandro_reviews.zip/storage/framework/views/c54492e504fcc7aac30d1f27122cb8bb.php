<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h1>Nieuwe Inzending</h1>
    <ul>
        <li>Naam:<?php echo e($data['naam']); ?></li>
        <li>E-mailadres:<?php echo e($data['email']); ?></li>
        <li>Score:<?php echo e($data['score']); ?></li>
        <li>Bericht:<?php echo e($data['bericht']); ?></li>
    </ul>
</body>

</html>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\reviews\resources\views/mails/formnotification.blade.php ENDPATH**/ ?>