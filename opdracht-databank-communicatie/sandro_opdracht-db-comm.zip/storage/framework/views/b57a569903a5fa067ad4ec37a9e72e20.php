<?php $__empty_1 = true; $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="even:bg-gray-100 odd:bg-gray-200">
        <td class="p-2 text-lg flex flex-col">
            <a href="<?php echo e(route('publishers.show', $publisher->id)); ?>" class="hover:underline"><?php echo e($publisher->name); ?></a>
            <span class="text-gray-500 text-sm"><?php echo e($publisher->games()->count()); ?> games</span>
        </td>
        <td class="p-2">
            <a href="<?php echo e(route('publishers.show', $publisher->id)); ?>"
                class="px-4 py-1 bg-blue-200 hover:bg-blue-300 text-blue-500 hover:text-blue-600">View</a>
            <?php echo $__env->make('publishers.includes.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <p>No games yet</p>
<?php endif; ?>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-databank-communicatie\resources\views/publishers/includes/publisher-row.blade.php ENDPATH**/ ?>