<?php $__env->startSection('title', 'Publishers'); ?>

<?php $__env->startSection('content'); ?>

    <div class="py-4">
        <a class="bg-green-200 hover:bg-green-300 text-green-600 px-4 py-2 inline-block" href="<?php echo e(route('publishers.create')); ?>">Add new publisher &rarr;</a>
    </div>

    <h2 class="text-4xl font-semibold mb-4">Publishers</h2>

    <?php echo $__env->make('publishers.includes.publisher-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-databank-communicatie\resources\views/publishers/index.blade.php ENDPATH**/ ?>