<table class="w-full text-left shadow-2xl">
    <tr class="bg-gray-300">
        <th class="p-2">Publisher</th>
        <th class="p-2">Actions</th>
    </tr>
    <?php echo $__env->make('publishers.includes.publisher-row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</table>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-databank-communicatie\resources\views/publishers/includes/publisher-table.blade.php ENDPATH**/ ?>