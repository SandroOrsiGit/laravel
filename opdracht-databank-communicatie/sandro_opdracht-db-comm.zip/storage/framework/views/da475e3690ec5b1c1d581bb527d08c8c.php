<div class="grid gap-4">
    <div>
        <label class="block text-lg text-gray-500 mb-2" for="name">Name</label>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-sm text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input class="px-4 py-2 rounded w-full bg-gray-200 shadow-inner" type="text" name="name" id="name"
            value="<?php echo e(old('name', $game->name)); ?>">
    </div>
    <div>
        <label class="block text-lg text-gray-500 mb-2" for="publisher_id">Publisher</label>
        <?php $__errorArgs = ['publisher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-sm text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <select class="px-4 py-2 rounded w-full bg-gray-200 shadow-inner" name="publisher_id" id="publisher_id">
            <option disabled>-- Select a publisher</option>
            <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($publisher->id); ?>" <?php echo e(old('publisher_id', $publisher->id)); ?>>
                    <?php echo e($publisher->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    </div>
    <div class="mt-4 py-4 border-t border-gray-300">
        <label class="block text-lg text-gray-500 flex items-center gap-2">
            <input type="checkbox" name="completed" id="completed"
                <?php echo e(old('completed', $game->completed) ? 'checked' : ''); ?>>
            <span>Completed</span>
        </label>
    </div>

    <div>
        <input
            class="cursor-pointer inline-block px-4 py-2 bg-green-200 text-green-600 hover:bg-green-300 hover:text-green-700"
            type="submit" value="<?php echo e($buttonText ?? 'Save'); ?>">
    </div>
</div>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-databank-communicatie\resources\views/games/includes/form.blade.php ENDPATH**/ ?>