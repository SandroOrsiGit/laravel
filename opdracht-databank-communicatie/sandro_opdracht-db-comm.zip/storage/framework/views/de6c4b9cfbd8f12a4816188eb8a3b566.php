<?php $__env->startSection('title', 'My games'); ?>

<?php $__env->startSection('content'); ?>

    <div class="py-4">
        <a class="bg-green-200 hover:bg-green-300 text-green-600 px-4 py-2 inline-block" href="<?php echo e(route('games.create')); ?>">Add new game &rarr;</a>
    </div>

    <h2 class="text-4xl font-semibold mb-4">Games</h2>

    <?php echo $__env->make('games.includes.game-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-databank-communicatie\resources\views/games/index.blade.php ENDPATH**/ ?>