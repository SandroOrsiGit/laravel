<a class="px-4 py-1 bg-orange-200 hover:bg-orange-300 text-orange-500 hover:text-orange-600"
    href="<?php echo e(route('publishers.edit', $publisher->id)); ?>">Edit</a>
<a class="px-4 py-1 bg-red-200 hover:bg-red-300 text-red-500 hover:text-red-600"
    href="<?php echo e(route('publishers.delete', $publisher->id)); ?>">Delete</a>
<?php /**PATH C:\Users\fuw\Desktop\github\laravel\opdracht-databank-communicatie\resources\views/publishers/includes/actions.blade.php ENDPATH**/ ?>